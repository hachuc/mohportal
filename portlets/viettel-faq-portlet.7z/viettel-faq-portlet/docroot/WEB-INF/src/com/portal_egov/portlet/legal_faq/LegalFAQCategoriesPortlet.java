package com.portal_egov.portlet.legal_faq;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class LegalFAQCategoriesPortlet
 */
public class LegalFAQCategoriesPortlet extends MVCPortlet {
 

}
