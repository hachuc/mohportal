/**
 * @author ChucHV
 * @time 10:16:45 AM
 * @project legal_fag-portlet
 */
package com.portal_egov.portlet.legal_faq.action;


public class LegalFAQViewConfigActionImpl {
	
}
